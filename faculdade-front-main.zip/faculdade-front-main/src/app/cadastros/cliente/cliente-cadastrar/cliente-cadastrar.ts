import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-cadastrar',
  imports: [],
  templateUrl: './cliente-cadastrar.html',
  styleUrl: './cliente-cadastrar.scss'
})
export class ClienteCadastrar {

}
