import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-listar',
  imports: [],
  templateUrl: './cliente-listar.html',
  styleUrl: './cliente-listar.scss'
})
export class ClienteListar {

}
